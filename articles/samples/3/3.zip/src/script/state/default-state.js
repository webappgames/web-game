const defaultState = {
    blocks: [{id:'My first block!!!',position:{x:0,y:0,z:0}}]
};